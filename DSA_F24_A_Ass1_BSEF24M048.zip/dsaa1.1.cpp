#include<iostream>
#include<stack>
#include<vector>
#include<string>
#include<cctype>
#include<cstdlib>
using namespace std;

bool isOperator(const string& op)
{
	return op == "+" || op == "*" || op == "/"|| op=="-";

}
int precedencee(const string& op)
{
	if (op == "*" || op == "/")
	{
		return 2;
	}
	if (op == "+" || op == "-")
	{
		return 1;
	}
	return 0;
}
bool isNumber(const string& str)
{
	if (str.empty())
	{
		return false;
	}
	for (int i = 0;i < str.length();i++)
	{
		if (!isdigit(str[i]))
		{
			return false;
		}

	}
	return true;
}
bool isVariable(const string& str)
{
	if (str.empty())
	{
		return false;
	}
	if (!(isalpha(str[0]) || str[0] == '_'))
	{
		return false;
	}
	for (int i = 1;i < str.length();i++)
	{
		if (!(isalnum(str[i]) || str[i] == '_'))
		{
			return false;
		}
	}
	return true;
}
vector<string> tokenize(const string& exp)
{
	vector<string>token;
	int i = 0;
	while (i < exp.length())
	{
		if (exp[i] == ' ')
		{
			i++;
			continue;
		}
		if (isdigit(exp[i]))
		{
			string num = "";
			while (i < exp.length() && isdigit(exp[i]))
			{
				num += exp[i];
				i++;
			}
			token.push_back(num);
		}
		else if (isalpha(exp[i]) || exp[i] == '_')
		{
			string var = "";
			while (i < exp.length() && (isalnum(exp[i]) || exp[i] == '_'))
			{
				var += exp[i];
				i++;
			}
			token.push_back(var);
		}
		else
		{
			string temp = "";
			temp += exp[i];
			token.push_back(temp);
			i++;
		}
	}
	return token;
}
vector<string> infixToPostfix(vector<string>& tokens)
{
	vector<string>postfix;
	stack<string>s;
	for (int i = 0;i < tokens.size();i++)
	{
		string current = tokens[i];
		if (isNumber(current) || isVariable(current))
		{
			postfix.push_back(current);
		}
		else if (current == "(" || current == "[" || current == "{")
		{
			s.push(current);
		}

		else if (current == ")" || current == "]" || current == "}")
		{
			bool found = false;

			while (!s.empty())
			{
				string top = s.top();

				if (
					(current == ")" && top == "(") ||
					(current == "]" && top == "[") ||
					(current == "}" && top == "{")
					)
				{
					found = true;
					s.pop();
					break;
				}

				postfix.push_back(top);
				s.pop();
			}

			if (!found)
			{
				cerr << "syntax error\n";
				exit(1);
			}
		}
		else if (isOperator(current))
		{
			while (!s.empty() && isOperator(s.top()) && precedencee(s.top()) >= precedencee(current))
			{
				postfix.push_back(s.top());
				s.pop();

			}
			s.push(current);
			
		}
		else
		{
			cerr << "syntax error\n";
			exit(1);
		}
	}
	while (!s.empty())
	{
		if (s.top() == "(" ||
			s.top() == "[" ||
			s.top() == "{")
		{
			cerr << "syntax error\n";
			exit(1);
		}
		postfix.push_back(s.top());
		s.pop();


	}
	return postfix;
}
int getValue(string var, string names[], int values[], int& total)
{
	for (int i = 0;i < total;i++)
	{
		if (names[i] == var)
		{
			return values[i];
		}
	}

	int val;
	cerr << "enter value for" << var << ":";
	cin >> val;

	names[total] = var;
	values[total] = val;

	total++;

	return val;
}

int evaluatePostfix(vector<string>& postfix)
{
	stack<int>s;

	string names[100];
	int values[100];

	int total = 0;

	for (int i = 0;i < postfix.size();i++)
	{
		string current = postfix[i];

		if (isNumber(current))
		{
			s.push(stoi(current));
		}
		else if (isVariable(current))
		{
			int val = getValue(current, names, values, total);
			s.push(val);
		}
		else if (isOperator(current))
		{
			if (s.size() < 2)
			{
				cerr << "logical errorr\n";
				exit(3);
			}
			int b = s.top();
			s.pop();

			int a = s.top();
			s.pop();
			if (current == "+")
			{
				s.push(a + b);
			}
			else if (current == "-")
			{
				s.push(a - b);
			}
			else if (current == "*")
			{
				s.push(a * b);
			}
			else if (current == "/")
			{
				if (b == 0)
				{
					cerr << "runtime rerrir";
					exit(2);
				}
				s.push(a / b);
			}
		}
	}
	if (s.size() != 1)
	{
		cerr << "logical error\n";
		exit(3);
	}
	return s.top();
}
int main()
{
	string expression;
	getline(cin, expression);
	if (expression.empty())
	{
		cerr << "syntax error\n";
		return 1;

	}
	vector<string> tokens = tokenize(expression);
	vector<string> postfix = infixToPostfix(tokens);
	for (int i = 0;i < postfix.size();i++)
	{
		cerr << postfix[i];
		if (i != postfix.size() - 1)
		{
			cerr << " ";
		}
	}
	cerr<<"\n";

	int result = evaluatePostfix(postfix);
	cout << result;
	return 0;
}